// Custom classifier parser (generated).
// Scaffold validates the output layer and exposes `logits`/`numClasses`; the
// DECODE block (per-model) populates `attrList` and `descString`.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "nvdsinfer_custom_impl.h"

typedef bool (*NvDsInferClassifierParseWithLabelsFunc)(
    std::vector<NvDsInferLayerInfo> const& outputLayersInfo,
    NvDsInferNetworkInfo const& networkInfo,
    float classifierThreshold,
    std::vector<std::vector<std::string>> const& labels,
    std::vector<NvDsInferAttribute>& attrList,
    std::string& descString);

#define CHECK_CUSTOM_CLASSIFIER_WITH_LABELS_PARSE_FUNC_PROTOTYPE(customParseFunc) \
    static void checkFunc_ ## customParseFunc ( \
        NvDsInferClassifierParseWithLabelsFunc func = customParseFunc) \
        { checkFunc_ ## customParseFunc (); }; \
    extern "C" bool customParseFunc( \
        std::vector<NvDsInferLayerInfo> const& outputLayersInfo, \
        NvDsInferNetworkInfo const& networkInfo, \
        float classifierThreshold, \
        std::vector<std::vector<std::string>> const& labels, \
        std::vector<NvDsInferAttribute>& attrList, \
        std::string& descString);

extern "C" bool ParseConfigClassifierPgie(
    std::vector<NvDsInferLayerInfo> const& outputLayersInfo,
    NvDsInferNetworkInfo const& networkInfo,
    float classifierThreshold,
    std::vector<std::vector<std::string>> const& labels,
    std::vector<NvDsInferAttribute>& attrList,
    std::string& descString);

CHECK_CUSTOM_CLASSIFIER_WITH_LABELS_PARSE_FUNC_PROTOTYPE(ParseConfigClassifierPgie);

extern "C" bool ParseConfigClassifierPgie(
    std::vector<NvDsInferLayerInfo> const& outputLayersInfo,
    NvDsInferNetworkInfo const& /*networkInfo*/,
    float classifierThreshold,
    std::vector<std::vector<std::string>> const& labels,
    std::vector<NvDsInferAttribute>& attrList,
    std::string& descString)
{
    if (outputLayersInfo.empty()) return false;
    auto const& layer = outputLayersInfo[0];
    if (layer.dataType != FLOAT) {
        fprintf(stderr, "[FloraBot] expected FLOAT output, got dataType=%d\n", (int)layer.dataType);
        return false;
    }

    unsigned numClasses = 0;
    if (layer.inferDims.numDims == 1) numClasses = layer.inferDims.d[0];
    else if (layer.inferDims.numDims == 2) numClasses = layer.inferDims.d[1];
    else { fprintf(stderr, "[FloraBot] unexpected numDims=%d\n", layer.inferDims.numDims); return false; }

    const float* logits = static_cast<const float*>(layer.buffer);

    static bool logged = false;
    if (!logged) {
        logged = true;
        fprintf(stderr, "[FloraBot] first call: numClasses=%u labels.size()=%zu threshold=%.3f\n",
                numClasses, labels.size(), classifierThreshold);
    }

    // ==== BEGIN GENERATED DECODE ====
    // Numerically-stable softmax
    float maxLogit = logits[0];
    for (unsigned i = 1; i < numClasses; i++) {
        if (logits[i] > maxLogit) maxLogit = logits[i];
    }

    std::vector<float> probs(numClasses);
    float sumExp = 0.0f;
    for (unsigned i = 0; i < numClasses; i++) {
        probs[i] = std::exp(logits[i] - maxLogit);
        sumExp += probs[i];
    }
    for (unsigned i = 0; i < numClasses; i++) {
        probs[i] /= sumExp;
    }

    // Find top-1
    unsigned bestIdx = 0;
    float bestProb = probs[0];
    for (unsigned i = 1; i < numClasses; i++) {
        if (probs[i] > bestProb) {
            bestProb = probs[i];
            bestIdx = i;
        }
    }

    // Build the label string
    std::string labelStr;
    if (!labels.empty() && labels[0].size() > static_cast<size_t>(bestIdx)) {
        labelStr = labels[0][bestIdx];
    } else {
        labelStr = "class_" + std::to_string(bestIdx);
    }

    // Only push if above threshold (threshold is 0.0 so top-1 always passes)
    if (bestProb >= classifierThreshold) {
        NvDsInferAttribute attr;
        attr.attributeIndex = 0;
        attr.attributeValue = static_cast<int>(bestIdx);
        attr.attributeConfidence = bestProb;
        attr.attributeLabel = strdup(labelStr.c_str());
        attrList.push_back(attr);

        descString = labelStr;
    }
    // ==== END GENERATED DECODE ====
    return true;
}